/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.algoritmosp3;

/**
 *
 * @author Delga
 */
import java.util.Arrays;

public class Pila<T> {

    private int tope;
    private T[] pila;
    private int size;

    public Pila(int size) {
        pila = (T[]) new Object[size];
        this.size = size;
        tope = -1;
    }

    public boolean pila_llena() {
        return tope == pila.length - 1;
    }

    public boolean pila_vacia() {
        return tope == -1;
    }

    public T pop() {
        T dato = null;
        if (pila_vacia()) {
            System.out.println("Subdesbordamiento");
        } else {
            dato = pila[tope];
            tope--;
        }
        return dato;
    }

    public void push(T dato) {
        if (pila_llena()) {
            System.out.println("Desbordamiento");
            aumentarTamano();
        }
        tope++;
        pila[tope] = dato;

    }

    public T peek() {
        if (pila_vacia()) {
            System.out.println("La pila está vacía");
            return null;
        }
        return pila[tope];
    }

    public void aumentarTamano() {
        // Crear una nueva pila
        Pila<T> nuevaPila = new Pila<>(pila.length * 2);
        // Pasar los elementos de la pila actual a la nueva pila
        while (!pila_vacia()) {
            nuevaPila.push(pop());
        }
        //reordenar
        pila = (T[]) new Object[nuevaPila.size];
        tope = -1;

        while (!nuevaPila.pila_vacia()) {
            push(nuevaPila.pop());
        }
    }


    public int getSize() {
        return tope+1;
    }

    @Override
    public String toString() {
        return "Pila{"
                + "tope=" + tope
                + ", pila=" + Arrays.toString(pila)
                + '}';
    }
}
