/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.algoritmosp3;

/**
 *
 * @author Delga
 */
public class Triangulo {

    private double ladoA;
    private double ladoB;
    private double ladoC;
    private double anguloA;
    private double anguloB;
    private double anguloC;
    private boolean trianguloValido;
    private double area;
    private double perimetro;
    private String tipoTriangulo;

    public Triangulo() {

    }

    public Triangulo(double ladoA, double ladoB, double ladoC, double anguloA, double anguloB, double anguloC) {
        this.ladoA = ladoA;
        this.ladoB = ladoB;
        this.ladoC = ladoC;
        this.anguloA = anguloA;
        this.anguloB = anguloB;
        this.anguloC = anguloC;
        this.perimetro = round(ladoA + ladoB + ladoC, 4);
    }

    public boolean validarTriangulo(Triangulo triangulo) {
        return (ladoA + ladoB > ladoC) && (ladoA + ladoC > ladoB) && (ladoB + ladoC > ladoA);
    }

    public double convertirAnguloRadianes(double angulo) {
        return round(Math.toRadians(angulo), 4);
    }

    public double calcularArea() {
        return round(0.5 * this.ladoA * this.ladoB * Math.sin(Math.toRadians(this.anguloC)), 4);
    }

    public double calcularPerimetro() {
        return round(this.perimetro, 4);
    }

    public double calcularSemiperimetro() {
        return round(getPerimetro() * 0.5, 4);
    }

    public double calcularAlturaA() {
        return round((2 * calcularArea()) / this.ladoA, 4);
    }

    public double calcularAlturaB() {
        return round(2 * calcularArea() / this.ladoB, 4);
    }

    public double calcularAlturaC() {
        return round(2 * calcularArea() / this.ladoC, 4);
    }

    public double calcularMedianaA() {
        return round(Math.sqrt(Math.pow(ladoA / 2, 2) + Math.pow(ladoC, 2) - (ladoA * ladoC * Math.cos(Math.toRadians(anguloB)))), 4);
    }

    public double calcularMedianaB() {
        return round(Math.sqrt(Math.pow(ladoB / 2, 2) + Math.pow(ladoA, 2) - (ladoA * ladoB * Math.cos(Math.toRadians(anguloC)))), 4);
    }

    public double calcularMedianaC() {
        return round(Math.sqrt(Math.pow(ladoC / 2, 2) + Math.pow(ladoB, 2) - (ladoB * ladoC * Math.cos(Math.toRadians(anguloA)))), 4);
    }

    public double calcularRadioInscrito() {
        return round(calcularArea() / calcularSemiperimetro(), 4);
    }

    public double calcularRadioCircunscrito() {
        double anguloARadianes = Math.toRadians(anguloA);
        double senoAnguloA = Math.sin(anguloARadianes);
        if (senoAnguloA == 0) {
            throw new ArithmeticException("El seno del ángulo no puede ser 0.");
        }
        return round(ladoA / (2 * senoAnguloA), 4);
    }

    public double getPerimetro() {
        return round(perimetro, 4);
    }

    public String getTipoTriangulo() {
        // Redondear los lados a 4 decimales
        double ladoARedondo = Math.round(ladoA * 10000.0) / 10000.0;
        double ladoBRedondo = Math.round(ladoB * 10000.0) / 10000.0;
        double ladoCRedondo = Math.round(ladoC * 10000.0) / 10000.0;

        // Comparar los lados redondeados
        if (ladoARedondo == ladoBRedondo && ladoARedondo == ladoCRedondo) {
            return "Equilatero";
        } else if (ladoARedondo != ladoBRedondo && ladoARedondo != ladoCRedondo && ladoBRedondo != ladoCRedondo) {
            return "Escaleno";
        } else {
            return "Isosceles";
        }
    }

    public double getLadoA() {
        return round(ladoA, 4);
    }

    public void setLadoA(double ladoA) {
        this.ladoA = ladoA;
    }

    public double getLadoB() {
        return round(ladoB, 4);
    }

    public void setLadoB(double ladoB) {
        this.ladoB = ladoB;
    }

    public double getLadoC() {
        return round(ladoC, 4);
    }

    public void setLadoC(double ladoC) {
        this.ladoC = ladoC;
    }

    public double getAnguloA() {
        return round(anguloA, 4);
    }

    public void setAnguloA(double anguloA) {
        this.anguloA = anguloA;
    }

    public double getAnguloB() {
        return round(anguloB, 4);
    }

    public void setAnguloB(double anguloB) {
        this.anguloB = anguloB;
    }

    public double getAnguloC() {
        return round(anguloC, 4);
    }

    public void setAnguloC(double anguloC) {
        this.anguloC = anguloC;
    }

    // Método auxiliar para redondear a 4 decimales
    private double round(double value, int places) {
        double scale = Math.pow(10, places);
        return Math.round(value * scale) / scale;
    }
}
