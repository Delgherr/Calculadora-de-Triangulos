/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.algoritmosp3;

/**
 *
 * @author Delga
 */
import java.util.Arrays;

public class ColaCircular<T> {

    private int inicio;
    private int fin;
    private int max;
    private T[] cola;

    public ColaCircular() {
    }

    public ColaCircular(int max) {
        this.fin = -1;
        this.inicio = -1;
        this.max = max;
        this.cola = (T[]) new Object[max];
    }

    // Método para insertar un dato en la cola circular
    public void insertarDato(T dato) {
        if ((fin + 1) % max == inicio) {
            System.out.println("Desbordamiento: la cola está llena");
            return;
        }
        fin = (fin + 1) % max;
        cola[fin] = dato;
        if (inicio == -1) {
            inicio = 0;
        }
    }

    // Método para eliminar un dato de la cola circular
    public T eliminarDato() {
        if (inicio == -1) {
            System.out.println("Subdesbordamiento: la cola está vacía");
            return null;
        }
        T dato = cola[inicio];
        cola[inicio] = null;
        if (inicio == fin) {
            inicio = -1;
            fin = -1;
        } else {
            inicio = (inicio + 1) % max;
        }
        return dato;
    }

    // Método para mostrar el contenido de la cola
    public void mostrarCola() {
        if (inicio == -1) {
            System.out.println("La cola está vacía");
            return;
        }
        System.out.print("Contenido de la cola: ");
        int i = inicio;
        while (true) {
            System.out.print(cola[i] + " ");
            if (i == fin) {
                break;
            }
            i = (i + 1) % max;
        }
        System.out.println();
    }

    @Override
    public String toString() {
        return "colaCircular{"
                + "inicio=" + inicio
                + ", fin=" + fin
                + ", max=" + max
                + ", cola=" + Arrays.toString(cola)
                + '}';
    }

    public T verSiguiente(int indice) {
        if (indice < 0 || indice > fin || inicio == -1) {
            return null; // Índice inválido o cola vacía
        }

        // Crear una cola auxiliar para no modificar la cola original
        ColaCircular<T> colaAuxiliar = new ColaCircular<>(max);

        // Ingresar elementos a la cola auxiliar
        int i = inicio;
        while (true) {
            colaAuxiliar.insertarDato(cola[i]); // Insertar en la auxiliar
            if (i == fin) {
                break; // Se han copiado todos los elementos
            }
            i = (i + 1) % max; // Avanzar circularmente
        }

        // Recorrer la cola auxiliar hasta llegar al índice deseado
        for (int j = 0; j <= indice; j++) {
            T dato = colaAuxiliar.eliminarDato(); // Obtener dato de la auxiliar
            if (j == indice) {
                return dato; // Retornar el dato en el índice solicitado
            }
        }
        return null;
    }

    
    public T peek() {
        if (inicio == -1) {
            System.out.println("La cola está vacía");
            return null;
        }
        return cola[inicio];
    }
}
