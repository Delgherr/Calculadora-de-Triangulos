/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.algoritmosp3;

/**
 *
 * @author Delga
 */
import java.util.Arrays;

public class ColaSimple<T> {

    private int inicio;
    private int fin;
    private T[] colaSimple;
    private int max;
    private Pila<T> pilaRetroceso;

    public ColaSimple() {

    }

    public ColaSimple(int max) {
        this.max = max;
        this.inicio = -1;
        this.fin = -1;
        this.colaSimple = (T[]) new Object[max];
        this.pilaRetroceso = new Pila(1);
    }

    public void insertarDato(T dato) {
        // Si hay espacio para insertar
        if (fin < max - 1) {
            // Si es la primera vez que se inserta un dato
            if (inicio == -1) {
                inicio = 0; // Iniciar la cola en la posición 0
            }
            fin++; // Avanzar el índice del fin
            colaSimple[fin] = dato; // Insertar el dato en la posición correcta
        } else {
            System.out.println("Desbordamiento"); // La cola está llena
        }
    }

    public T eliminarDato() {
        T dato = null;

        // Si la cola no está vacía
        if (inicio != -1) {
            dato = colaSimple[inicio]; // Obtener el dato en la posición de inicio

            // Si solo queda un dato en la cola, reiniciar índices
            if (inicio == fin) {
                inicio = -1;
                fin = -1;
            } else {
                inicio++; // Avanzar el índice del inicio para simular la eliminación
            }
        } else {
            System.out.println("Subdesbordamiento"); // La cola está vacía
        }

        return dato;
    }

    public T peek() {
        if (inicio != -1) {
            return colaSimple[inicio]; // Mostrar el dato en la posición de inicio
        } else {
            System.out.println("Cola vacía"); // La cola está vacía
            return null;
        }
    }

    @Override
    public String toString() {
        return "ColaSimple{"
                + "inicio=" + inicio
                + ", fin=" + fin
                + ", colaSimple=" + Arrays.toString(colaSimple)
                + ", max=" + max
                + '}';
    }

    //Metodo para obtener dato de una posicion especifica
    public T verSiguiente(int indice) {
        if (indice < 0 || indice > fin) {
            return null;
        }

        // Crear una cola auxiliar para no modificar la cola original
        ColaSimple<T> colaAuxiliar = new ColaSimple<>(max);

        // ingresar elementos a cola auxiliar
        for (int i = inicio; i <= fin; i++) {
            colaAuxiliar.insertarDato(colaSimple[i]);
        }

        for (int i = 0; i <= indice; i++) {
            T dato = colaAuxiliar.eliminarDato(); //obtener dato
            if (i == indice) {
                return dato; 
            }
        }
        return null;
    }

}
