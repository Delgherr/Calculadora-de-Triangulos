/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.algoritmosp3;

/**
 *
 * @author Delga
 */
//JRDH
public class Calculadora {

    // CONOZCO LA MEDIDA DE LOS 3 LADOS
    public double calcularAnguloConTresLados(double a, double b, double c, int anguloIndex) {
        double[] angulos = new double[3];
        angulos[0] = calcularAngulo(a, b, c); // A
        angulos[1] = calcularAngulo(b, a, c); // B
        angulos[2] = calcularAngulo(c, a, b); // C
        return angulos[anguloIndex];
    }

    // Calcular un angulo especifico dado tres lados utilizando ley coseno
    private double calcularAngulo(double lado1, double lado2, double lado3) {
        return Math.toDegrees(Math.acos((Math.pow(lado2, 2) + Math.pow(lado3, 2) - Math.pow(lado1, 2)) / (2 * lado2 * lado3)));
    }

    //DOS LADOS Y EL ANGULO ENTRE ELLOS
    public double calcularTercerLado(double lado1, double lado2, double angulo) {
        double anguloEnRadianes = Math.toRadians(angulo);
        // Aplicar la ley de los cosenos
        double tercerLado = Math.sqrt(Math.pow(lado1, 2) + Math.pow(lado2, 2) - 2 * lado1 * lado2 * Math.cos(anguloEnRadianes));
        return tercerLado;
    }

    //Calcular el angulo b, teniendo una pareja y el lado b
    public double calcularConLeySenoAngulo(double ladoA, double ladoB, double anguloA) {
        double anguloARadianes = Math.toRadians(anguloA); // Convertir el a radianes
        double anguloBRadianes = Math.asin((ladoB * Math.sin(anguloARadianes)) / ladoA);
        double anguloB = Math.toDegrees(anguloBRadianes); // Convertir a grados

        return anguloB;
    }

    //Calcular el tercer angulo teniendo los otros dos
    public double calcularAnguloConAngulos(double anguloA, double anguloB) {
        return 180 - anguloA - anguloB;
    }

    //Calcular lado b con ley seno conociendo una parea y el angulo b
    public double calcularConLeySenoLado(double ladoA, double anguloA, double anguloB) {
        // Aplicar la Ley de los Senos
        return (ladoA * Math.sin(Math.toRadians(anguloB))) / Math.sin(Math.toRadians(anguloA));
    }

    //Comprobar caso con los datos ingresador por le usuario
    public double[] regresarDatos(double ladoA, double ladoB, double ladoC, double anguloA, double anguloB, double anguloC) {
        Calculadora calculadora = new Calculadora();
        if(ladoA != 0 && ladoB != 0 && ladoC != 0){
            anguloA = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,0);
            anguloB = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,1);
            anguloC = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,2);

            //2 lados y el angulo entre ellos
        }else if (ladoA != 0 && ladoB != 0 && anguloC != 0){
            ladoC = calculadora.calcularTercerLado(ladoA,ladoB,anguloC);
            anguloA = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,0);
            anguloB = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,1);
        }else if (ladoA != 0 && ladoC != 0 && anguloB != 0){
            ladoB = calculadora.calcularTercerLado(ladoA,ladoC,anguloB);
            anguloA = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,0);
            anguloC = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,2);
        }else if(ladoB != 0 && ladoC != 0 && anguloA != 0){
            ladoA = calculadora.calcularTercerLado(ladoB,ladoC,anguloA);
            anguloB = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,1);
            anguloC = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,2);

            //2 LADOS Y EL ANGULO CORRESPONDIENTE A UNO DE ELLOS
        }else if(ladoA != 0 && ladoC != 0 && anguloA != 0){
            anguloC = calculadora.calcularConLeySenoAngulo(ladoA,ladoC,anguloA);
            anguloB = calculadora.calcularAnguloConAngulos(anguloA,anguloC);
            ladoB = calculadora.calcularTercerLado(ladoA,ladoC,anguloB);
        }else if(ladoA != 0 && ladoC != 0 && anguloC != 0){
            anguloA = calculadora.calcularConLeySenoAngulo(ladoC,ladoA,anguloC);
            anguloB = calculadora.calcularAnguloConAngulos(anguloA,anguloC);
            ladoB = calculadora.calcularTercerLado(ladoA,ladoC,anguloB);
        }else if(ladoB != 0 && ladoC != 0 && anguloB != 0){
            anguloC = calculadora.calcularConLeySenoAngulo(ladoB,ladoC,anguloB);
            anguloA = calculadora.calcularAnguloConAngulos(anguloC,anguloB);
            ladoA = calculadora.calcularTercerLado(ladoC,ladoB,anguloA);//REVISAR
        }else if(ladoB != 0 && ladoC != 0 && anguloC != 0){
            anguloB = calculadora.calcularConLeySenoAngulo(ladoC,ladoB,anguloC);
            anguloA = calculadora.calcularAnguloConAngulos(anguloB,anguloC);
            ladoA = calculadora.calcularTercerLado(ladoB,ladoC,anguloA);//REVISAR
        }else if(ladoB != 0 && ladoA != 0 && anguloA != 0){
            anguloB = calculadora.calcularConLeySenoAngulo(ladoA,ladoB,anguloA);
            anguloC = calculadora.calcularAnguloConAngulos(anguloB,anguloA);
            ladoC = calculadora.calcularTercerLado(ladoB,ladoA,anguloC);
        }else if(ladoB != 0 && ladoA != 0 && anguloB != 0){
            anguloA = calculadora.calcularConLeySenoAngulo(ladoB,ladoA,anguloB);
            anguloC = calculadora.calcularAnguloConAngulos(anguloB,anguloA);
            ladoC = calculadora.calcularTercerLado(ladoB,ladoA,anguloC);

            //1 LADO Y 2 ANGULOS A SUS LADOS
        }else if(ladoA != 0 && anguloC != 0 && anguloB != 0){
            anguloA = calculadora.calcularAnguloConAngulos(anguloC, anguloB);
            ladoB = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloB);
            ladoC = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloC);
        }else if(ladoB != 0 && anguloC != 0 && anguloA != 0){
            anguloB = calculadora.calcularAnguloConAngulos(anguloC, anguloA);
            ladoA = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloA);
            ladoC = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloC);
        }else if(ladoC != 0 && anguloA != 0 && anguloB != 0){
            anguloC = calculadora.calcularAnguloConAngulos(anguloB, anguloA);
            ladoA = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloA);
            ladoB = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloB);

            //2 ANGULOS Y UN LADO QUE CORRESPONDE A UNO DE ELLOS
        }else if (ladoA != 0 && anguloA != 0 && anguloB != 0) {
            ladoB = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloB);
            anguloC = calculadora.calcularAnguloConAngulos(anguloB, anguloA);
            ladoC = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloC);
        }else if (ladoA != 0 && anguloA != 0 && anguloC != 0) {
            ladoC = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloC);
            anguloB = calculadora.calcularAnguloConAngulos(anguloC, anguloA);
            ladoB = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloB);
        }else if (ladoB != 0 && anguloB != 0 && anguloA != 0) {
            ladoA = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloA);
            anguloC = calculadora.calcularAnguloConAngulos(anguloB, anguloA);
            ladoC = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloC);
        }else if (ladoB != 0 && anguloB != 0 && anguloC != 0){
            ladoC = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloC);
            anguloA = calculadora.calcularAnguloConAngulos(anguloB, anguloC);
            ladoA = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloA);
        }else if (ladoC != 0 && anguloC != 0 && anguloA != 0) {
            ladoA = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloA);
            anguloB = calculadora.calcularAnguloConAngulos(anguloC, anguloA);
            ladoB = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloB);
        }else if(ladoC != 0 && anguloC != 0 && anguloB != 0){
            ladoB = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloB);
            anguloA = calculadora.calcularAnguloConAngulos(anguloC, anguloB);
            ladoA = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloA);
        }
        double []datos = new double[6];
        datos[0] = ladoA;
        datos[1] = ladoB;
        datos[2] = ladoC;
        datos[3] = anguloA;
        datos[4] = anguloB;
        datos[5] = anguloC;

        return datos;
    }
}