import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Calculadora calculadora = new Calculadora();
        double[] medidasTriangulo = new double[6];

        // Pedir al usuario que ingrese los valores
        System.out.println("Ingrese 3 valores del triangulo, al menos uno debe ser lado (utilizar 0 si no se conoce):");

        double ladoA;
        do {
            System.out.print("Lado A: ");
            ladoA = scanner.nextDouble();
            if (ladoA < 0) {
                System.out.println("El valor no puede ser negativo. Por favor, ingresa un valor positivo o 0.");
            }
        } while (ladoA < 0);

        double ladoB;
        do {
            System.out.print("Lado B: ");
            ladoB = scanner.nextDouble();
            if (ladoB < 0) {
                System.out.println("El valor no puede ser negativo");
            }
        } while (ladoB < 0);

        double ladoC;
        do {
            System.out.print("Lado C: ");
            ladoC = scanner.nextDouble();
            if (ladoC < 0) {
                System.out.println("El valor no puede ser negativo");
            }
        } while (ladoC < 0);

        double anguloA;
        do {
            System.out.print("Ángulo A: ");
            anguloA = scanner.nextDouble();
            if (anguloA < 0) {
                System.out.println("El valor no puede ser negativo");
            }
        } while (anguloA < 0);

        double anguloB;
        do {
            System.out.print("Ángulo B: ");
            anguloB = scanner.nextDouble();
            if (anguloB < 0) {
                System.out.println("El valor no puede ser negativo");
            }
        } while (anguloB < 0);

        double anguloC;
        do {
            System.out.print("Ángulo C: ");
            anguloC = scanner.nextDouble();
            if (anguloC < 0) {
                System.out.println("El valor no puede ser negativo");
            }
        } while (anguloC < 0);

        // Determinar el metodo a utilizar segun los valores conocidos
        if (ladoA > 0 && ladoB > 0 && ladoC > 0) {
            // Conocemos los 3 lados
            medidasTriangulo = calculadora.calcularAngulosConTresLados(ladoA, ladoB, ladoC);

        //Conocemos un par y un lado
        } else if (anguloA > 0 && ladoA > 0 && ladoB > 0) {
            medidasTriangulo = calculadora.calcularAnguloConLeySenos(ladoA, anguloA, ladoB);
        } else if (anguloA > 0 && ladoA > 0 && ladoC > 0) {
            medidasTriangulo = calculadora.calcularAnguloConLeySenos(ladoA, anguloA, ladoC);
        } else if (anguloB > 0 && ladoB > 0 && ladoA > 0) {
            medidasTriangulo = calculadora.calcularAnguloConLeySenos(ladoB, anguloB, ladoA);
        } else if (anguloB > 0 && ladoB > 0 && ladoC > 0) {
            medidasTriangulo = calculadora.calcularAnguloConLeySenos(ladoB, anguloB, ladoC);
        } else if (anguloC > 0 && ladoC > 0 && ladoA > 0) {
            medidasTriangulo = calculadora.calcularAnguloConLeySenos(ladoC, anguloC, ladoA);
        } else if (anguloC > 0 && ladoC > 0 && ladoB > 0) {
            medidasTriangulo = calculadora.calcularAnguloConLeySenos(ladoC, anguloC, ladoB);

        //Dos lados y un angulo que no corresponde a ninguno de ellos
        } else if (ladoB > 0 && ladoC > 0 && anguloA > 0) {
            medidasTriangulo = calculadora.calcularLadoConLeyCoseno(anguloA, ladoB, ladoC);
        } else if (ladoA > 0 && ladoC > 0 && anguloB > 0) {
            medidasTriangulo = calculadora.calcularLadoConLeyCoseno(anguloB, ladoC, ladoA);
        } else if (ladoA > 0 && ladoB > 0 && anguloC > 0) {
            medidasTriangulo = calculadora.calcularLadoConLeyCoseno(anguloC, ladoA, ladoB);

        //Conocemos dos angulos y un lado que no corresponde a ninguno de llos
        } else if (anguloA > 0 && anguloB > 0 && ladoC > 0) {
            medidasTriangulo = calculadora.calcularLadoConMedidasSinPareja(anguloA, anguloB, ladoC);
        } else if (anguloB > 0 && anguloC > 0 && ladoA > 0) {
            medidasTriangulo = calculadora.calcularLadoConMedidasSinPareja(anguloB, anguloC, ladoA);
        } else if (anguloA > 0 && anguloC > 0 && ladoB > 0) {
            medidasTriangulo = calculadora.calcularLadoConMedidasSinPareja(anguloA, anguloC, ladoB);

        //Conocemos dos angulos y un lado correspondiente a uno de ellos
        } else if (anguloA > 0 && ladoA > 0 && anguloB > 0) {
            medidasTriangulo = calculadora.calcularLadoConLeySenos(anguloA, ladoA, anguloB);
        } else if (anguloA > 0 && ladoA > 0 && anguloC > 0) {
            medidasTriangulo = calculadora.calcularLadoConLeySenos(anguloA, ladoA, anguloC);
        } else if (anguloB > 0 && ladoB > 0 && anguloC > 0) {
            medidasTriangulo = calculadora.calcularLadoConLeySenos(anguloB, ladoB, anguloC);
        } else if (anguloB > 0 && ladoB > 0 && anguloA > 0) {
            medidasTriangulo = calculadora.calcularLadoConLeySenos(anguloB, ladoB, anguloA);
        } else if (anguloC > 0 && ladoC > 0 && anguloA > 0) {
            medidasTriangulo = calculadora.calcularLadoConLeySenos(anguloC, ladoC, anguloA);
        } else if (anguloC > 0 && ladoC > 0 && anguloB > 0) {
            medidasTriangulo = calculadora.calcularLadoConLeySenos(anguloC, ladoC, anguloB);
        }
        else {
            System.out.println("Los datos ingresados no son correctos");
            return;
        }

        //ORDENAR VALORES PARA QUE CORRESPONDAN AL ORDEN INGRESADO POR EL USUARIO
        double [] datosOrdenados = new double[medidasTriangulo.length];

        if(ladoA == medidasTriangulo[0] || anguloA == medidasTriangulo[3]){
            datosOrdenados[0] = medidasTriangulo[0];
            datosOrdenados[3] = medidasTriangulo[3];

            medidasTriangulo[0] = 0;
            medidasTriangulo[3] = 0;
        }else if (ladoA == medidasTriangulo[1] || anguloA == medidasTriangulo[4]){
            datosOrdenados[0] = medidasTriangulo[1];
            datosOrdenados[3] = medidasTriangulo[4];

            medidasTriangulo[1] = 0;
            medidasTriangulo[4] = 0;
        }else if(ladoA == medidasTriangulo[2] || anguloA == medidasTriangulo[5]){
            datosOrdenados[0] = medidasTriangulo[2];
            datosOrdenados[3] = medidasTriangulo[5];

            medidasTriangulo[2] = 0;
            medidasTriangulo[5] = 0;
        }

        if(ladoB == medidasTriangulo[0] || anguloB == medidasTriangulo[3]){
            datosOrdenados[1] = medidasTriangulo[0];
            datosOrdenados[4] = medidasTriangulo[3];

            medidasTriangulo[0] = 0;
            medidasTriangulo[3] = 0;
        }else if(ladoB == medidasTriangulo[1] || anguloB == medidasTriangulo[4]) {
            datosOrdenados[1] = medidasTriangulo[1];
            datosOrdenados[4] = medidasTriangulo[4];

            medidasTriangulo[1] = 0;
            medidasTriangulo[4] = 0;
        }else if (ladoB == medidasTriangulo[2] || anguloB == medidasTriangulo[5]) {
            datosOrdenados[1] = medidasTriangulo[2];
            datosOrdenados[4] = medidasTriangulo[5];

            medidasTriangulo[2] = 0;
            medidasTriangulo[5] = 0;
        }

        if(ladoC == medidasTriangulo[0] || anguloC == medidasTriangulo[3]){
            datosOrdenados[2] = medidasTriangulo[0];
            datosOrdenados[5] = medidasTriangulo[3];

            medidasTriangulo[0] = 0;
            medidasTriangulo[3] = 0;
        }else if(ladoC == medidasTriangulo[1] || anguloC == medidasTriangulo[4]) {
            datosOrdenados[2] = medidasTriangulo[1];
            datosOrdenados[5] = medidasTriangulo[4];

            medidasTriangulo[1] = 0;
            medidasTriangulo[4] = 0;
        }else if(ladoC == medidasTriangulo[2] || anguloC == medidasTriangulo[5]) {
            datosOrdenados[2] = medidasTriangulo[2];
            datosOrdenados[5] = medidasTriangulo[5];

            medidasTriangulo[2] = 0;
            medidasTriangulo[5] = 0;
        }

        for (int i = 0; i < medidasTriangulo.length; i++) {
            if (medidasTriangulo[i] != 0) { // Si el valor de medidasTriangulo es diferente de 0
                for (int j = 0; j < datosOrdenados.length; j++) {
                    if (datosOrdenados[j] == 0) { // Si el valor de datosOrdenados es 0
                        datosOrdenados[j] = medidasTriangulo[i]; // Reemplazar el valor
                        break;
                    }
                }
            }
        }

        Triangulo miTriangulo = new Triangulo(datosOrdenados[0], datosOrdenados[1], datosOrdenados[2],
                datosOrdenados[3],datosOrdenados[4],datosOrdenados[5]);
        if(miTriangulo.validarTriangulo(miTriangulo)){
            // Mostrar los resultados
            System.out.println("\nTipo de triangulo: " + miTriangulo.getTipoTriangulo());

            System.out.println("\nLado A: " + miTriangulo.getLadoA());
            System.out.println("Lado B: " + miTriangulo.getLadoB());
            System.out.println("Lado C: " + miTriangulo.getLadoC());
            System.out.println("\nÁngulo A: " + miTriangulo.getAnguloA());
            System.out.println("Ángulo B: " + miTriangulo.getAnguloB());
            System.out.println("Ángulo C: " + miTriangulo.getAnguloC());

            System.out.println("\nÁngulo A en radianes: " + miTriangulo.convertirAnguloRadianes(miTriangulo.getAnguloA()));
            System.out.println("Ángulo B en radianes: " + miTriangulo.convertirAnguloRadianes(miTriangulo.getAnguloB()));
            System.out.println("Ángulo C en radianes: " + miTriangulo.convertirAnguloRadianes(miTriangulo.getAnguloC()));
            System.out.println("\nÁrea: " + miTriangulo.calcularArea());
            System.out.println("Perimetro: " + miTriangulo.calcularPerimetro());
            System.out.println("Semiperimetro: " + miTriangulo.calcularSemiperimetro());
            System.out.println("\nAltura A: " + miTriangulo.calcularAlturaA());
            System.out.println("Altura B: " + miTriangulo.calcularAlturaB());
            System.out.println("Altura C: " + miTriangulo.calcularAlturaC());
            System.out.println("\nMediana A: " + miTriangulo.calcularMedianaA());
            System.out.println("Mediana B: " + miTriangulo.calcularMedianaB());
            System.out.println("Mediana C: " + miTriangulo.calcularMedianaC());
            System.out.println("\nInradius r: " + miTriangulo.calcularRadioInscrito());
            System.out.println("Circumradius R: " + miTriangulo.calcularRadioCircunscrito());
        }else{
            System.out.println("El triangulo no es valido");
        }

    }
}
