public class Calculadora {

    // CONOZCO LA MEDIDA DE LOS 3 LADOS
    public double[] calcularAngulosConTresLados(double a, double b, double c) {
        double[] resultado = new double[6];
        resultado[0] = a;
        resultado[1] = b;
        resultado[2] = c;
        resultado[3] = calcularAngulo(a, b, c); // calcular A
        resultado[4] = calcularAngulo(b, a, c); // calcular B
        resultado[5] = calcularAngulo(c, a, b); // calcular C
        return resultado;
    }

    // Calcular un angulo especifico dado tres lados
    private double calcularAngulo(double lado1, double lado2, double lado3) {
        return Math.toDegrees(Math.acos((Math.pow(lado2, 2) + Math.pow(lado3, 2) - Math.pow(lado1, 2)) / (2 * lado2 * lado3)));
    }

    // CONOZCO UNA PAREJA DE DATOS Y UN ÁNGULO
    public double[] calcularLadoConLeySenos(double angulo1, double lado1, double angulo2) {
        double[] resultado = new double[6];
        resultado[3] = angulo1;
        resultado[4] = angulo2;
        resultado[0] = lado1;
        // Calcular el otro lado
        double lado2 = (lado1 * Math.sin(Math.toRadians(angulo2))) / Math.sin(Math.toRadians(angulo1));
        resultado[1] = lado2;
        double angulo3 = 180 - angulo1 - angulo2;
        resultado[5] = angulo3;
        // Calcular el tercer lado usando la Ley de Senos
        resultado[2] = (lado2 * Math.sin(Math.toRadians(angulo3))) / Math.sin(Math.toRadians(angulo2));

        return resultado;
    }

    // CONOZCO UNA PAREJA DE DATOS Y UN LADO
    public double[] calcularAnguloConLeySenos(double lado1, double angulo1, double lado2) {
        double[] resultado = new double[6];
        resultado[0] = lado1;
        resultado[1] = lado2;
        resultado[3] = angulo1;

        // Calcular el segundo angulo usando la Ley de Senos
        double angulo2 = Math.toDegrees(Math.asin((lado2 * Math.sin(Math.toRadians(angulo1))) / lado1));
        resultado[4] = angulo2;

        // Calcular el tercer ángulo
        double angulo3 = 180 - angulo1 - angulo2;
        resultado[5] = angulo3;

        // Calcular el tercer lado usando la Ley de Senos
        resultado[2] = (lado2 * Math.sin(Math.toRadians(angulo3))) / Math.sin(Math.toRadians(angulo2));

        return resultado;
    }

    // CONOZCO 2 LADOS Y UN ANGULO QUE NO SON PAREJA
    public double[] calcularLadoConLeyCoseno(double angulo1, double lado2, double lado3) {
        double[] resultado = new double[6];
        resultado[1] = lado2; // lado2
        resultado[2] = lado3; // lado3
        resultado[5] = angulo1; // angulo1 en grados

        // Calcular el lado restante usando la Ley de Coseno
        double lado1 = Math.sqrt(Math.pow(lado2, 2) + Math.pow(lado3, 2) - 2 * lado2 * lado3 * Math.cos(Math.toRadians(angulo1)));
        resultado[0] = lado1; // lado1 calculado

        // Calcular los angulos restantes usando la Ley de Coseno
        double anguloB = calcularAnguloConLeyCoseno(lado1, lado2, lado3);
        resultado[3] = anguloB; // ánguloB calculado
        double anguloC = calcularAnguloConLeyCoseno(lado1, lado3, lado2);
        resultado[4] = anguloC;

        return resultado;
    }

    // Metodo para calcular un angulo usando la Ley de Coseno
    private double calcularAnguloConLeyCoseno(double ladoA, double ladoB, double ladoC) {
        //Ley de Coseno para calcular el angulo opuesto al ladoC
        double anguloRad = Math.acos((Math.pow(ladoA, 2) + Math.pow(ladoB, 2) - Math.pow(ladoC, 2)) / (2 * ladoA * ladoB));
        return Math.toDegrees(anguloRad);
    }


    // CONOZCO 2 ANGULOS Y UN LADO QUE NO SON PAREJA
    public double[] calcularLadoConMedidasSinPareja(double angulo1, double angulo2, double lado3) {
        double[] resultado = new double[6];
        resultado[3] = angulo1;
        resultado[4] = angulo2;
        resultado[2] = lado3;

        // Calcular el tercer angulo
        double angulo3 = 180 - angulo1 - angulo2;
        resultado[5] = angulo3;

        // Calcular los lados restantes usando la Ley de Senos
        resultado[0] = (lado3 * Math.sin(Math.toRadians(angulo1))) / Math.sin(Math.toRadians(angulo3)); // Lado opuesto al angulo1
        resultado[1] = (lado3 * Math.sin(Math.toRadians(angulo2))) / Math.sin(Math.toRadians(angulo3)); // Lado opuesto al angulo2

        return resultado;
    }
}
