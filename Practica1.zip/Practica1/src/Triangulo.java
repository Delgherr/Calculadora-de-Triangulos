public class Triangulo {
    private double ladoA;
    private double ladoB;
    private double ladoC;
    private double anguloA;
    private double anguloB;
    private double anguloC;
    private boolean trianguloValido;
    private double area;
    private double perimetro;
    private String tipoTriangulo;

    public Triangulo() {

    }

    public Triangulo(double ladoA, double ladoB, double ladoC, double anguloA,
                     double anguloB, double anguloC){
        this.ladoA = ladoA;
        this.ladoB = ladoB;
        this.ladoC = ladoC;
        this.anguloA = anguloA;
        this.anguloB = anguloB;
        this.anguloC = anguloC;
        this.perimetro = ladoA + ladoB + ladoC;
    }

    public boolean validarTriangulo(Triangulo miTriangulo){
        boolean valido = false;
        if((ladoA + ladoB) > ladoC){
            if((ladoA + ladoC) > ladoB){
                if((ladoB + ladoC) > ladoA){
                    valido = true;
                }
            }
        }
        return valido;
    }

    public double convertirAnguloRadianes(double angulo){
        return Math.toRadians(angulo);
    }

    public double calcularArea() {
        return 0.5 * this.ladoA * this.ladoB * Math.sin(Math.toRadians(this.anguloC));
    }

    public double calcularPerimetro(){
        return this.perimetro;
    }

    public double calcularSemiperimetro(){
        //return (ladoA + ladoB + ladoC)*.5;
        return getPerimetro()*.5;
    }

    public double calcularAlturaA(){
        return ((2*(calcularArea()))/this.ladoA);
    }

    public double calcularAlturaB(){
        return (2*calcularArea()/this.ladoB);
    }

    public double calcularAlturaC(){
        return (2*calcularArea()/this.ladoC);
    }

    public double calcularMedianaA() {
        return Math.sqrt(Math.pow(ladoA / 2, 2) + Math.pow(ladoC, 2) - (ladoA * ladoC * Math.cos(Math.toRadians(anguloB))));
    }


    public double calcularMedianaB(){
        return Math.sqrt(Math.pow(ladoB / 2, 2) + Math.pow(ladoA, 2) - (ladoA * ladoB * Math.cos(Math.toRadians(anguloC))));
    }

    public double calcularMedianaC(){
        return Math.sqrt(Math.pow(ladoC / 2, 2) + Math.pow(ladoB, 2) - (ladoB * ladoC * Math.cos(Math.toRadians(anguloA))));
    }

    public double calcularRadioInscrito(){
        return calcularArea()/calcularSemiperimetro();
    }

    public double calcularRadioCircunscrito(){
        return ladoA/(2*Math.asin(Math.toRadians(anguloA)));
    }

    public double getPerimetro() {
        return perimetro;
    }

    public String getTipoTriangulo() {
        if(ladoA == ladoB && ladoA == ladoC){
            return "Equilatero";
        }else if(ladoA != ladoB && ladoA != ladoC && ladoB != ladoC){
            return "Escaleno";
        }else{
            return "Isosceles";
        }
    }

    public double getLadoA() {
        return ladoA;
    }

    public void setLadoA(double ladoA) {
        this.ladoA = ladoA;
    }

    public double getLadoB() {
        return ladoB;
    }

    public void setLadoB(double ladoB) {
        this.ladoB = ladoB;
    }

    public double getLadoC() {
        return ladoC;
    }

    public void setLadoC(double ladoC) {
        this.ladoC = ladoC;
    }

    public double getAnguloA() {
        return anguloA;
    }

    public void setAnguloA(double anguloA) {
        this.anguloA = anguloA;
    }

    public double getAnguloB() {
        return anguloB;
    }

    public void setAnguloB(double anguloB) {
        this.anguloB = anguloB;
    }

    public double getAnguloC() {
        return anguloC;
    }

    public void setAnguloC(double anguloC) {
        this.anguloC = anguloC;
    }


}
