public class GraphicTriangulo {
}
