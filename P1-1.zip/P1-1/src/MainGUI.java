public class MainGUI {

    public static void main(String[] args) {

        /*GUICalculadora calculadora = new GUICalculadora();
        calculadora.setVisible(true);*/
        /* java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUICalculadora().setVisible(true);
            }
        });*/

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUICalculadora().setVisible(true);
            }
        });
    }
}