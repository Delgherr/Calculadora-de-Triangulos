import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int op = 0;
        int control;
        int contDatos;
        do {
            control = 0;
            contDatos = 0;
            System.out.println("\n\n------------------------");
            System.out.println("MENU");
            System.out.println("------------------------");
            System.out.println("[1] Calculadora de Triangulo");
            System.out.println("[2] Salir");
            System.out.print("Opcion: ");
            try {
                op = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Por favor, ingresa un número válido.");
                scanner.next(); // Limpiar el scanner
                continue; // Volver al inicio
            }

            if (op == 1) {


                Calculadora calculadora = new Calculadora();
                double[] medidasTriangulo = new double[6];

                // Pedir al usuario que ingrese los valores
                System.out.println("\nIngrese UNICAMENTE 3 valores del triangulo, al menos uno debe ser lado (utilizar 0 si no se conoce):");

                double ladoA;
                do {
                    System.out.print("Lado A: ");
                    try {
                        ladoA = scanner.nextDouble();
                        if (ladoA < 0) {
                            System.out.println("El valor no puede ser negativo. Por favor, ingresa un valor positivo o 0.");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Por favor, ingresa un número válido.");
                        scanner.next(); // Limpiar el scanner
                        ladoA = -1; // Para que continue el ciclo
                    }
                } while (ladoA < 0);

                double ladoB;
                do {
                    System.out.print("Lado B: ");
                    try {
                        ladoB = scanner.nextDouble();
                        if (ladoB < 0) {
                            System.out.println("El valor no puede ser negativo.");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Por favor, ingresa un número válido.");
                        scanner.next();
                        ladoB = -1;
                    }
                } while (ladoB < 0);

                double ladoC;
                do {
                    System.out.print("Lado C: ");
                    try {
                        ladoC = scanner.nextDouble();
                        if (ladoC < 0) {
                            System.out.println("El valor no puede ser negativo.");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Por favor, ingresa un número válido.");
                        scanner.next();
                        ladoC = -1;
                    }
                } while (ladoC < 0);

                double anguloA;
                do {
                    System.out.print("Ángulo A: ");
                    try {
                        anguloA = scanner.nextDouble();
                        if (anguloA < 0) {
                            System.out.println("El valor no puede ser negativo.");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Por favor, ingresa un número válido.");
                        scanner.next();
                        anguloA = -1;
                    }
                } while (anguloA < 0);

                double anguloB;
                do {
                    System.out.print("Ángulo B: ");
                    try {
                        anguloB = scanner.nextDouble();
                        if (anguloB < 0) {
                            System.out.println("El valor no puede ser negativo.");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Por favor, ingresa un número válido.");
                        scanner.next();
                        anguloB = -1;
                    }
                } while (anguloB < 0);

                double anguloC;
                do {
                    System.out.print("Ángulo C: ");
                    try {
                        anguloC = scanner.nextDouble();
                        if (anguloC < 0) {
                            System.out.println("El valor no puede ser negativo.");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Por favor, ingresa un número válido.");
                        scanner.next();
                        anguloC = -1;
                    }
                } while (anguloC < 0);


                if (ladoA != 0) {
                    contDatos++;
                }
                if (ladoB != 0) {
                    contDatos++;
                }
                if (ladoC != 0) {
                    contDatos++;
                }
                if (anguloA != 0) {
                    contDatos++;
                }
                if (anguloB != 0) {
                    contDatos++;
                }
                if (anguloC != 0) {
                    contDatos++;
                }

                if (contDatos == 3) {



                    // Determinar el metodo a utilizar segun los valores conocidos
                    //conozco los 3 lados, obtenr 3 angulos
                    /*if(ladoA != 0 && ladoB != 0 && ladoC != 0){
                        anguloA = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,0);
                        anguloB = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,1);
                        anguloC = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,2);

                    //2 lados y el angulo entre ellos
                    }else if (ladoA != 0 && ladoB != 0 && anguloC != 0){
                        ladoC = calculadora.calcularTercerLado(ladoA,ladoB,anguloC);
                        anguloA = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,0);
                        anguloB = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,1);
                    }else if (ladoA != 0 && ladoC != 0 && anguloB != 0){
                        ladoB = calculadora.calcularTercerLado(ladoA,ladoC,anguloB);
                        anguloA = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,0);
                        anguloC = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,2);
                    }else if(ladoB != 0 && ladoC != 0 && anguloA != 0){
                        ladoA = calculadora.calcularTercerLado(ladoB,ladoC,anguloA);
                        anguloB = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,1);
                        anguloC = calculadora.calcularAnguloConTresLados(ladoA,ladoB,ladoC,2);

                    //2 LADOS Y EL ANGULO CORRESPONDIENTE A UNO DE ELLOS
                    }else if(ladoA != 0 && ladoC != 0 && anguloA != 0){
                        anguloC = calculadora.calcularConLeySenoAngulo(ladoA,ladoC,anguloA);
                        anguloB = calculadora.calcularAnguloConAngulos(anguloA,anguloC);
                        ladoB = calculadora.calcularTercerLado(ladoA,ladoC,anguloB);
                    }else if(ladoA != 0 && ladoC != 0 && anguloC != 0){
                        anguloA = calculadora.calcularConLeySenoAngulo(ladoC,ladoA,anguloC);
                        anguloB = calculadora.calcularAnguloConAngulos(anguloA,anguloC);
                        ladoB = calculadora.calcularTercerLado(ladoA,ladoC,anguloB);
                    }else if(ladoB != 0 && ladoC != 0 && anguloB != 0){
                        anguloC = calculadora.calcularConLeySenoAngulo(ladoB,ladoC,anguloB);
                        anguloA = calculadora.calcularAnguloConAngulos(anguloC,anguloB);
                        ladoA = calculadora.calcularTercerLado(ladoC,ladoB,anguloA);//REVISAR
                    }else if(ladoB != 0 && ladoC != 0 && anguloC != 0){
                        anguloB = calculadora.calcularConLeySenoAngulo(ladoC,ladoB,anguloC);
                        anguloA = calculadora.calcularAnguloConAngulos(anguloB,anguloC);
                        ladoA = calculadora.calcularTercerLado(ladoB,ladoC,anguloA);//REVISAR
                    }else if(ladoB != 0 && ladoA != 0 && anguloA != 0){
                        anguloB = calculadora.calcularConLeySenoAngulo(ladoA,ladoB,anguloA);
                        anguloC = calculadora.calcularAnguloConAngulos(anguloB,anguloA);
                        ladoC = calculadora.calcularTercerLado(ladoB,ladoA,anguloC);
                    }else if(ladoB != 0 && ladoA != 0 && anguloB != 0){
                        anguloA = calculadora.calcularConLeySenoAngulo(ladoB,ladoA,anguloB);
                        anguloC = calculadora.calcularAnguloConAngulos(anguloB,anguloA);
                        ladoC = calculadora.calcularTercerLado(ladoB,ladoA,anguloC);

                    //1 LADO Y 2 ANGULOS A SUS LADOS
                    }else if(ladoA != 0 && anguloC != 0 && anguloB != 0){
                        anguloA = calculadora.calcularAnguloConAngulos(anguloC, anguloB);
                        ladoB = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloB);
                        ladoC = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloC);
                    }else if(ladoB != 0 && anguloC != 0 && anguloA != 0){
                        anguloB = calculadora.calcularAnguloConAngulos(anguloC, anguloA);
                        ladoA = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloA);
                        ladoC = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloC);
                    }else if(ladoC != 0 && anguloA != 0 && anguloB != 0){
                        anguloC = calculadora.calcularAnguloConAngulos(anguloB, anguloA);
                        ladoA = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloA);
                        ladoB = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloB);

                    //2 ANGULOS Y UN LADO QUE CORRESPONDE A UNO DE ELLOS
                    }else if (ladoA != 0 && anguloA != 0 && anguloB != 0) {
                        ladoB = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloB);
                        anguloC = calculadora.calcularAnguloConAngulos(anguloB, anguloA);
                        ladoC = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloC);
                    }else if (ladoA != 0 && anguloA != 0 && anguloC != 0) {
                        ladoC = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloC);
                        anguloB = calculadora.calcularAnguloConAngulos(anguloC, anguloA);
                        ladoB = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloB);
                    }else if (ladoB != 0 && anguloB != 0 && anguloA != 0) {
                        ladoA = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloA);
                        anguloC = calculadora.calcularAnguloConAngulos(anguloB, anguloA);
                        ladoC = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloC);
                    }else if (ladoB != 0 && anguloB != 0 && anguloC != 0){
                        ladoC = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloC);
                        anguloA = calculadora.calcularAnguloConAngulos(anguloB, anguloC);
                        ladoA = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloA);
                    }else if (ladoC != 0 && anguloC != 0 && anguloA != 0) {
                        ladoA = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloA);
                        anguloB = calculadora.calcularAnguloConAngulos(anguloC, anguloA);
                        ladoB = calculadora.calcularConLeySenoLado(ladoA,anguloA,anguloB);
                    }else if(ladoC != 0 && anguloC != 0 && anguloB != 0){
                        ladoB = calculadora.calcularConLeySenoLado(ladoC,anguloC,anguloB);
                        anguloA = calculadora.calcularAnguloConAngulos(anguloC, anguloB);
                        ladoA = calculadora.calcularConLeySenoLado(ladoB,anguloB,anguloA);
                    }*/

                    /*System.out.println("Medidas");
                    System.out.println("lado a: " + ladoA);
                    System.out.println("lado b: " + ladoB);
                    System.out.println("lado c: " + ladoC);
                    System.out.println("anguloA: " + anguloA);
                    System.out.println("anguloB: " + anguloB);
                    System.out.println("anguloC: " + anguloC);*/
                    double []datos = calculadora.regresarDatos(ladoA,ladoB,ladoC,anguloA,anguloB,anguloC);
                    Triangulo miTriangulo = new Triangulo(datos[0],datos[1],datos[2],datos[3]
                            ,datos[4],datos[5]);

                    if (miTriangulo.validarTriangulo(miTriangulo)) {
                        // Mostrar los resultados
                        System.out.println("\nTipo de triangulo: " + miTriangulo.getTipoTriangulo());

                        System.out.println("\nLado A: " + miTriangulo.getLadoA());
                        System.out.println("Lado B: " + miTriangulo.getLadoB());
                        System.out.println("Lado C: " + miTriangulo.getLadoC());
                        System.out.println("\nÁngulo A: " + miTriangulo.getAnguloA());
                        System.out.println("Ángulo B: " + miTriangulo.getAnguloB());
                        System.out.println("Ángulo C: " + miTriangulo.getAnguloC());

                        System.out.println("\nÁngulo A en radianes: " + miTriangulo.convertirAnguloRadianes(miTriangulo.getAnguloA()));
                        System.out.println("Ángulo B en radianes: " + miTriangulo.convertirAnguloRadianes(miTriangulo.getAnguloB()));
                        System.out.println("Ángulo C en radianes: " + miTriangulo.convertirAnguloRadianes(miTriangulo.getAnguloC()));
                        System.out.println("\nÁrea: " + miTriangulo.calcularArea());
                        System.out.println("Perimetro: " + miTriangulo.calcularPerimetro());
                        System.out.println("Semiperimetro: " + miTriangulo.calcularSemiperimetro());
                        System.out.println("\nAltura A: " + miTriangulo.calcularAlturaA());
                        System.out.println("Altura B: " + miTriangulo.calcularAlturaB());
                        System.out.println("Altura C: " + miTriangulo.calcularAlturaC());
                        System.out.println("\nMediana A: " + miTriangulo.calcularMedianaA());
                        System.out.println("Mediana B: " + miTriangulo.calcularMedianaB());
                        System.out.println("Mediana C: " + miTriangulo.calcularMedianaC());
                        System.out.println("\nInradius r: " + miTriangulo.calcularRadioInscrito());
                        System.out.println("Circumradius R: " + miTriangulo.calcularRadioCircunscrito());
                    } else {
                        System.out.println("El triangulo no es valido");
                    }
                }else{
                    System.out.println("\nLa cantidad de datos ingresados no es correcta\n");
                }
            }else if(op == 2){
                System.out.println("\nFin del programa");

            }else{
                System.out.println("\nLa opcion solicita no es valida");
            }
        }while(op != 2);
    }
}
