/*public class Main2 {
    public static void main(String[] args) {
        Calculadora miCalculadora = new Calculadora();
        double angulo = miCalculadora.calcularAnguloConTresLados(13.23,8,20,1);
        System.out.println(angulo);

        if(lado)
    }
}
*/