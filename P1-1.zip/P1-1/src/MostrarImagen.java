import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class MostrarImagen extends JPanel {
    private Image imagen;

    public MostrarImagen() {
        // Cargar la imagen desde el archivo
        try {
            imagen = ImageIO.read(new File("tri.png")); // Asegúrate de que el archivo esté en la ruta correcta
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (imagen != null) {
            // Dibujar la imagen en el panel
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        }
    }

    public static void main(String[] args) {
        // Crear el marco (JFrame)
        JFrame ventana = new JFrame();
        ventana.setTitle("Mostrar Imagen");
        ventana.setSize(400, 400);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Agregar el panel que contiene la imagen
        MostrarImagen panel = new MostrarImagen();
        ventana.add(panel);

        // Hacer la ventana visible
        ventana.setVisible(true);
    }
}
